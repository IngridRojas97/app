package com.example.appmascotas.presentador;

public interface IRecyclerViewFragmentPresentador {

    public void obtenerMascotasBaseDatos();

    public void mostrarMascotaRecyclerView();

}
